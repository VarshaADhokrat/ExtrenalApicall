package com.MarchantSignupForm.service;

import com.MarchantSignupForm.dto.MerchantDto;
import com.MarchantSignupForm.model.MerchantInfo;

public interface MerchantInfoService {

        public MerchantInfo saveMerchantInfo(MerchantInfo merchantInfo);


//        public MerchantInfo getMerchantInfo(String personalId);
//        // Add other methods as needed
    }

