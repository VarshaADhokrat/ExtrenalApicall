package com.gllfl.MarchantSignupForm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarchantSignupFormApplicationTests {

	@Test
	void contextLoads() {
	}

}
